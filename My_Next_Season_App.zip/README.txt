MY NEXT SEASON — the shareable app
Created by Chengetai Shereni · © 2026

WHAT IT IS
The 12-week workbook as a phone app: set up one season (one goal, 8 milestones,
a start date), add weekly bites, tick them off to fill the 64-square grid, keep
a daily page, and review the season at the end. Past seasons are kept.
It also has a Vision Board (upload pictures of the life the season is walking
towards — they are stored on the phone with everything else) and a Money
section: the season's financial goal with a progress bar, plus three monthly
budgets with envelopes, planned vs actual.

HOW TO PUT IT ONLINE (Netlify, free)
1. Go to app.netlify.com and log in.
2. Sites → "Add new site" → "Deploy manually" (or drag this folder / the zip
   onto the deploys area of a new site).
3. Netlify gives you a link like something-random.netlify.app — you can rename
   it under Site settings (e.g. my-next-season).
4. Send that link to friends. It opens on any phone.

HOW FRIENDS' DATA WORKS
Each person's season is stored in their own phone's browser (localStorage).
Nothing is uploaded; nobody can see anyone else's entries — not even the site
owner. Two warnings to pass on:
- Use the same browser each time, and not a private/incognito window.
- If they clear their browser data or change phones, entries are gone —
  the Review tab has "Download a backup" (and Restore) for exactly that.

The matching printable workbook, "My Next Season" (PDF), carries the same
© 2026 Chengetai Shereni copyright page.
